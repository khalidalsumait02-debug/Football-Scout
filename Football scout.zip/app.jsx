/* app.jsx — moment tabs + tweaks for THE SCOUT wireframes */

const MOMENTS = [
  { id: 'home', n: '00', label: 'Setup', title: 'Home / game setup', render: () => <HomeMoment />,
    desc: () => <span>Get into the game fast. The whole arc is <span className="rule">7 drafts · 2 windows · 1 reveal</span> across 2016/17 → 2025/26.</span> },
  { id: 'draft', n: '01', label: 'Draft board ★', title: 'The draft board', render: () => <DraftMoment />,
    desc: () => <span>The core loop. <span className="rule">1 position opens per season · 5 anonymous cards · stats + value, no names</span>. Managers rotate picks; drafted players leave the board.</span> },
  { id: 'card', n: '02', label: 'Player card', title: 'The anonymous card', render: () => <CardMoment />,
    desc: () => <span>What a single prospect looks like. <span className="rule">Stats + market value shown — name hidden</span>. This card is the heart of the whole game.</span> },
  { id: 'turn', n: '03', label: 'Whose turn', title: 'Pick order & turn', render: () => <TurnMoment />,
    desc: () => <span>Managers rotate picks in a snake order; <span className="rule">drafted players leave the board</span> so scarcity builds round to round.</span> },
  { id: 'squad', n: '04', label: 'My squad', title: 'Squad view', render: () => <SquadMoment />,
    desc: () => <span>Your <span className="rule">7 slots: GK · CB · CB · DM · AM · WF · ST</span>, filling in across seasons. Outside the window, current values are visible.</span> },
  { id: 'window', n: '05', label: 'Transfer window ★', title: 'Transfer window — HOLD or SELL', render: () => <WindowMoment />,
    desc: () => <span>Twice in the game. <span className="rule">Values hidden</span> — decide HOLD or SELL each player on instinct alone.</span> },
  { id: 'replace', n: '06', label: 'Replacement', title: 'Replace a sold player', render: () => <ReplaceMoment />,
    desc: () => <span>Sell, then <span className="rule">replace from leftover undrafted players of that position's draft year, valued at that year</span>.</span> },
  { id: 'sale', n: '07', label: 'Sale reveal', title: 'Sale reveal — the payoff', render: () => <SaleMoment />,
    desc: () => <span><span className="rule">Sell price + buy price + profit revealed</span>. Banked profit counts toward your final score — and the gamble can sting.</span> },
  { id: 'final', n: '08', label: 'Final reveal ★', title: 'Final reveal & scoreboard', render: () => <FinalMoment />,
    desc: () => <span><span className="rule">Final squad value + cumulative banked profit = final score</span>. Profit revealed last for suspense. Highest total wins.</span> },
];

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#2f6df0",
  "density": "regular",
  "annotations": true,
  "whiteBg": false
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [active, setActive] = React.useState('draft');

  React.useEffect(() => {
    const r = document.documentElement;
    r.style.setProperty('--accent', t.accent);
    // derive a darker ink for the accent
    r.style.setProperty('--accent-ink', t.accent);
    document.body.classList.toggle('no-annot', !t.annotations);
    document.body.classList.toggle('dense', t.density === 'compact');
    document.body.classList.toggle('airy', t.density === 'airy');
    document.body.style.setProperty('--paper', t.whiteBg ? '#ffffff' : '#f4f1e8');
    document.body.style.setProperty('--screen', t.whiteBg ? '#ffffff' : '#fbfaf5');
  }, [t]);

  const m = MOMENTS.find((x) => x.id === active);

  return (
    <div className="wrap">
      <div className="masthead">
        <h1>The Scout<span className="tag">WIREFRAMES</span></h1>
        <div className="sub">Low-fi exploration of a hidden-value football drafting game. Each moment shows several divergent approaches — pick directions, then we go hi-fi. Mobile, one phone per manager.</div>
      </div>

      <div className="tabs" role="tablist">
        {MOMENTS.map((x) => (
          <button key={x.id} className="tab" role="tab" aria-selected={active === x.id} onClick={() => setActive(x.id)}>
            <span className="n">{x.n}</span>{x.label}
          </button>
        ))}
      </div>

      <div className="panel active" key={m.id}>
        <div className="panel-head">
          <h2>{m.title}</h2>
          <p>{m.desc()}</p>
        </div>
        {m.render()}
      </div>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Look" />
        <TweakColor label="Accent" value={t.accent}
          options={['#2f6df0', '#d8542c', '#2f8f57', '#7a4ad0', '#1d1b18']}
          onChange={(v) => setTweak('accent', v)} />
        <TweakToggle label="White (vs paper)" value={t.whiteBg} onChange={(v) => setTweak('whiteBg', v)} />
        <TweakSection label="Wireframe" />
        <TweakRadio label="Density" value={t.density} options={['compact', 'regular', 'airy']} onChange={(v) => setTweak('density', v)} />
        <TweakToggle label="Show annotations" value={t.annotations} onChange={(v) => setTweak('annotations', v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
