/* proto-card.jsx — premium anonymous card + shared UI bits */

function Silh({ size = 64, q = '?' }) {
  return (
    <div className="silh" style={{ width: size, height: size }}>
      <div className="qm" style={{ fontSize: size * 0.42 }}>{q}</div>
    </div>
  );
}

/* portrait photo placeholder — swaps to <img src> once the DB lands */
function Photo({ src, size = 64, radius = 16, ring }) {
  return (
    <div className="photo-ph" style={{ width: size, height: size, borderRadius: radius, boxShadow: ring ? '0 0 0 3px ' + ring : undefined }}>
      {src
        ? <img src={src} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: radius }} />
        : <React.Fragment>
            <div className="photo-head" />
            <div className="photo-body" />
            <span className="photo-tag">PHOTO</span>
          </React.Fragment>}
    </div>
  );
}

/* nameplate chip (placeholder name) */
function NamePlate({ name, tone = 'ink' }) {
  return <span className={"nameplate " + tone}>{name || 'Player —'}</span>;
}

function PosBadge({ pos, acc = true }) {
  return <span className={"pos-badge" + (acc ? " acc" : "")}>{pos}</span>;
}

/* full premium portrait card. value can be a node (e.g. masked) */
function PlayerCardFull({ p, value, tier, accentStats = true, sm = false }) {
  const tr = tier || tierOf(p.val);
  return (
    <div className={"pcard full " + tr + (sm ? " sm" : "")}>
      <div className="inner">
        <div className={"pc-top tier-ink " + tr}>
          <div className="pc-val">
            <div className="lab">Market value</div>
            <div className="num">{value !== undefined ? value : fmtM(p.val)}</div>
          </div>
          <div style={{ textAlign: 'right', display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6 }}>
            <PosBadge pos={p.pos} />
            {p.age && <span className="pill">age {p.age}</span>}
          </div>
        </div>
        <div className="pc-portrait"><Silh size={sm ? 72 : 104} /></div>
        <div className={"pc-sep tier-ink " + tr} />
        <div className="stat-grid">
          {STAT_KEYS.map((k) => (
            <div className="sg" key={k}>
              <span className="v" style={accentStats && p.stats[k] >= 80 ? { color: 'var(--acc)' } : null}>{p.stats[k]}</span>
              <span className="k">{k}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* mini landscape card used in the draft scroll list */
function PlayerCardMini({ p, onClick, taken, leaving }) {
  const tr = tierOf(p.val);
  return (
    <div className={"pcard mini " + tr + (onClick ? " tap-card" : "") + (leaving ? " leaving" : "")}
         onClick={taken ? undefined : onClick}>
      <div className="inner">
        {taken && <div className="taken-stamp"><span>DRAFTED</span></div>}
        <Silh size={48} />
        <div>
          <PosBadge pos={p.pos} />
          <div className="money" style={{ fontSize: 22, marginTop: 4 }}>{fmtM(p.val)}</div>
        </div>
        <div className="mini-stats">
          {['PAC', 'SHO', 'PHY'].map((k) => (
            <div className="sg" key={k} style={{ flexDirection: 'column', gap: 1, alignItems: 'center' }}>
              <span className="v">{p.stats[k]}</span><span className="k" style={{ fontSize: 9 }}>{k}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatBars({ stats }) {
  return (
    <div className="bars">
      {STAT_KEYS.map((k) => (
        <div className="bar-row" key={k}>
          <span className="k">{k}</span>
          <span className="track"><i style={{ width: stats[k] + '%' }} /></span>
          <span className="v">{stats[k]}</span>
        </div>
      ))}
    </div>
  );
}

function Snake({ now, done = [] }) {
  return (
    <div className="snake">
      {MANAGERS.map((m, i) => (
        <React.Fragment key={i}>
          <div className={"mgr" + (i === now ? " now" : "") + (done.includes(i) ? " done" : "")}>{m[0]}</div>
          {i < MANAGERS.length - 1 && <span className="arr">›</span>}
        </React.Fragment>
      ))}
    </div>
  );
}

function SceneHead({ kicker, title, sub }) {
  return (
    <div className="scene-head">
      {kicker && <div className="kicker">{kicker}</div>}
      <h1>{title}</h1>
      {sub && <p>{sub}</p>}
    </div>
  );
}

/* progress rail — step/total + label */
function Rail({ step, total, yr, phase }) {
  return (
    <div>
      <div className="rail">
        {Array.from({ length: total }).map((_, i) => (
          <div key={i} className={"seg" + (i < step ? " done" : i === step ? " now" : "")} style={{ marginRight: i < total - 1 ? 4 : 0 }} />
        ))}
      </div>
      <div className="rail-label">{yr ? <React.Fragment>Season <b>{yr}</b> · {phase}</React.Fragment> : <b>{phase}</b>}</div>
    </div>
  );
}

Object.assign(window, { Silh, Photo, NamePlate, PosBadge, PlayerCardFull, PlayerCardMini, StatBars, Snake, SceneHead, Rail });
