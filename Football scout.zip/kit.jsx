/* ============================================================
   kit.jsx — reusable low-fi wireframe primitives for THE SCOUT
   Thin wrappers over wireframe-kit.css. Exported to window.
   ============================================================ */

function Phone({ title, meta, children }) {
  return (
    <div className="phone">
      <div className="statusbar"><span>9:41</span><span>scout · ▦ ▤ ▰</span></div>
      <div className="screen">
        {(title || meta) && (
          <div className="s-top">
            <div className="ttl">{title}</div>
            {meta && <div className="meta">{meta}</div>}
          </div>
        )}
        {children}
      </div>
    </div>
  );
}

function Ln({ w, dark, style }) {
  const cls = "ln" + (dark ? " dark" : "") + (w ? " w" + w : "");
  return <div className={cls} style={style} />;
}

function Box({ children, soft, pad = 9, style, className = "" }) {
  return <div className={"box " + (soft ? "soft " : "") + className} style={{ padding: pad, ...style }}>{children}</div>;
}

function Dash({ label, style }) { return <div className="dash" style={style}>{label}</div>; }

function Chip({ children, fill, acc }) {
  return <span className={"chip" + (fill ? " fill" : "") + (acc ? " acc" : "")}>{children}</span>;
}

function Pos({ children, acc }) { return <span className={"pos" + (acc ? " acc" : "")}>{children}</span>; }

function Btn({ children, variant, block = true, style }) {
  const v = variant ? " " + variant : "";
  return <div className={"btn" + v + (block ? " block" : "")} style={style}>{children}</div>;
}

/* anonymous identity — the core "no name" idea */
function Anon({ label = "???", small }) {
  return (
    <div className="anon">
      <div className="silh" />
      <div>
        <div className="q" style={small ? { fontSize: 22 } : null}>{label}</div>
        {!small && <div className="who">name hidden</div>}
      </div>
    </div>
  );
}

/* stat bars from [{k, v}] (v 0-100) */
function Stats({ rows, acc }) {
  return (
    <div className="stats">
      {rows.map((r, i) => (
        <div className="stat" key={i}>
          <span>{r.k}</span>
          <span className="bar"><i className={acc && r.hi ? "acc" : ""} style={{ width: r.v + "%" }} /></span>
          <span className="v">{r.v}</span>
        </div>
      ))}
    </div>
  );
}

function Radar() { return <div className="radar"><div className="blob" /></div>; }

/* draft order: managers array, current index, done count */
function Snake({ mgrs, now, done = [] }) {
  return (
    <div className="snake">
      {mgrs.map((m, i) => (
        <React.Fragment key={i}>
          <div className={"mgr" + (i === now ? " now" : "") + (done.includes(i) ? " done" : "")}>{m}</div>
          {i < mgrs.length - 1 && <span className="arrow">›</span>}
        </React.Fragment>
      ))}
    </div>
  );
}

function Annot({ children, note, className = "" }) {
  return <div className={"annot " + (note ? "note " : "") + className}>{children}</div>;
}

/* a value tag — can be hidden (transfer window) */
function Val({ children, hidden }) {
  return <span className={"val" + (hidden ? " hidden-v" : "")}>{hidden ? "€ ? ? ?" : children}</span>;
}

/* variant column = phone + caption */
function Variant({ badge, name, desc, children }) {
  return (
    <div className="variant">
      {children}
      <div className="cap">
        <span className="badge">{badge}</span>
        <div className="name">{name}</div>
        <div className="desc">{desc}</div>
      </div>
    </div>
  );
}

Object.assign(window, { Phone, Ln, Box, Dash, Chip, Pos, Btn, Anon, Stats, Radar, Snake, Annot, Val, Variant });
