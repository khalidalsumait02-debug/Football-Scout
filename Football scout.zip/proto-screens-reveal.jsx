/* proto-screens-reveal.jsx — Squad value reveal (formation, one-by-one) */

/* tween that animates from the previous displayed value to the new target */
function useTween(target, ms = 650) {
  const [v, setV] = React.useState(0);
  const from = React.useRef(0);
  React.useEffect(() => {
    let raf, t0; const start = from.current;
    const tick = (t) => {
      if (!t0) t0 = t;
      const k = Math.min(1, (t - t0) / ms);
      const e = 1 - Math.pow(1 - k, 3);
      setV(start + (target - start) * e);
      if (k < 1) raf = requestAnimationFrame(tick);
      else { setV(target); from.current = target; }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target]);
  return v;
}

function SquadRevealScreen({ next }) {
  const sq = FINAL_SQUAD; // 0 ST · 1 WF · 2 DM · 3 AM · 4 CB · 5 CB · 6 GK
  const rows = [[0, 1], [2, 3], [4, 5], [6]];   // attack on top, keeper at the base
  const order = [6, 4, 5, 2, 3, 1, 0];          // reveal back-to-front, build to the striker

  const [n, setN] = React.useState(0);          // how many revealed so far
  const revealed = new Set(order.slice(0, n));
  const lastIdx = n > 0 ? order[n - 1] : null;
  const allDone = n >= order.length;

  const total = order.slice(0, n).reduce((a, i) => a + sq[i].fin, 0);
  const animTotal = useTween(total);
  const last = lastIdx != null ? sq[lastIdx] : null;

  return (
    <div className="scene">
      <Rail step={7} total={8} yr="25/26" phase="Squad value reveal" />
      <div className="app-body" style={{ display: 'flex', flexDirection: 'column' }}>
        <SceneHead kicker="Your final eleven" title="Squad Value"
          sub="Every player's market value at the final whistle — revealed one by one. This running total is the backbone of your score." />

        <div className="reveal-total" style={{ marginBottom: 10 }}>
          <div>
            <div className="lab">Squad value · 25/26</div>
            <div style={{ fontFamily: 'var(--font-d)', fontWeight: 600, fontSize: 11, letterSpacing: 1, color: 'rgba(255,255,255,.45)', marginTop: 2 }}>{n} of {sq.length} revealed</div>
          </div>
          <span className="amt">{fmtM(animTotal)}</span>
        </div>

        {/* identity caption for the player just revealed */}
        <div style={{ minHeight: 30, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 9, marginBottom: 8 }}>
          {last
            ? <div className="rise" key={'cap' + n} style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                <NamePlate name={last.name} tone="ink" />
                <span className="pos-badge acc">{last.pos}</span>
                <span className="money" style={{ fontSize: 19 }}>{fmtM(last.fin)}</span>
              </div>
            : <span className="label-sm">Tap reveal to start the count</span>}
        </div>

        <div className="pitch reveal" style={{ flex: 1, minHeight: 300, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          {rows.map((row, ri) => (
            <div className="prow" key={ri}>
              {row.map((i) => {
                const p = sq[i];
                const shown = revealed.has(i);
                const active = i === lastIdx && !allDone;
                return (
                  <div className={"rnode" + (active ? " active" : "")} key={i}>
                    <div className="ph-wrap">
                      <Photo src={p.photo} size={50} radius={14} />
                      <span className="pos-chip">{p.pos}</span>
                    </div>
                    {shown
                      ? <div className={"rval shown" + (i === lastIdx ? " pop" : "")} key={'v' + n}>{fmtM(p.fin)}</div>
                      : <div className="rval hidden">€?M</div>}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      <div className="sticky-foot">
        {!allDone
          ? <button className="btn primary" onClick={() => setN(n + 1)}>{n === 0 ? 'Reveal first value →' : 'Reveal next value →'}</button>
          : <button className="btn primary rise" onClick={next}>To the standings →</button>}
      </div>
    </div>
  );
}

Object.assign(window, { SquadRevealScreen, useTween });
