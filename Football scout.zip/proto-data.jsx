/* proto-data.jsx — abstract sample data + helpers for THE SCOUT */

const STAT_KEYS = ['PAC', 'SHO', 'PAS', 'DRI', 'DEF', 'PHY'];
const POS_ORDER = ['GK', 'CB', 'CB', 'DM', 'AM', 'WF', 'ST'];

function fmtM(v) {
  // v in millions
  if (v >= 100) return '€' + Math.round(v) + 'M';
  if (v >= 10) return '€' + (Math.round(v * 10) / 10).toString().replace(/\.0$/, '') + 'M';
  return '€' + (Math.round(v * 10) / 10) + 'M';
}
function tierOf(v) { return v >= 12 ? 'gold' : v >= 5 ? 'silver' : 'bronze'; }

/* ---- the ST draft pool: 5 anonymous prospects ---- */
const DRAFT_POOL = [
  { id: 'p1', pos: 'ST', age: 19, val: 4.2, stats: { PAC: 70, SHO: 61, PAS: 54, DRI: 66, DEF: 22, PHY: 58 } },
  { id: 'p2', pos: 'ST', age: 27, val: 11, stats: { PAC: 55, SHO: 80, PAS: 63, DRI: 71, DEF: 30, PHY: 84 } },
  { id: 'p3', pos: 'ST', age: 23, val: 6.8, stats: { PAC: 82, SHO: 66, PAS: 59, DRI: 74, DEF: 26, PHY: 60 } },
  { id: 'p4', pos: 'ST', age: 31, val: 2.1, stats: { PAC: 48, SHO: 88, PAS: 70, DRI: 69, DEF: 41, PHY: 79 } },
  { id: 'p5', pos: 'ST', age: 21, val: 18, stats: { PAC: 91, SHO: 84, PAS: 62, DRI: 79, DEF: 24, PHY: 55 } },
];

/* ---- your squad arriving at the transfer window (7 filled) ----
   buy = price paid at draft year · cur = current (hidden) value · stats abstract */
/* name/photo are PLACEHOLDERS — real player DB swaps in later */
const SQUAD = [
  { id: 's1', pos: 'GK', name: 'Player 01', photo: null, buy: 5.0, cur: 7.2, stats: { PAC: 52, SHO: 22, PAS: 58, DRI: 40, DEF: 38, PHY: 74 } },
  { id: 's2', pos: 'CB', name: 'Player 02', photo: null, buy: 4.0, cur: 9.0, stats: { PAC: 66, SHO: 30, PAS: 61, DRI: 52, DEF: 84, PHY: 82 } },
  { id: 's3', pos: 'CB', name: 'Player 03', photo: null, buy: 7.5, cur: 6.2, stats: { PAC: 58, SHO: 28, PAS: 66, DRI: 55, DEF: 80, PHY: 78 } },
  { id: 's4', pos: 'DM', name: 'Player 04', photo: null, buy: 6.0, cur: 13.5, stats: { PAC: 70, SHO: 55, PAS: 81, DRI: 77, DEF: 74, PHY: 76 } },
  { id: 's5', pos: 'AM', name: 'Player 05', photo: null, buy: 9.0, cur: 21.0, stats: { PAC: 84, SHO: 79, PAS: 86, DRI: 88, DEF: 40, PHY: 62 } },
  { id: 's6', pos: 'WF', name: 'Player 06', photo: null, buy: 6.0, cur: 2.6, stats: { PAC: 89, SHO: 66, PAS: 64, DRI: 85, DEF: 28, PHY: 55 } },
  { id: 's7', pos: 'ST', name: 'Player 07', photo: null, buy: 5.0, cur: 13.0, stats: { PAC: 91, SHO: 84, PAS: 62, DRI: 79, DEF: 24, PHY: 55 } },
];

/* end-of-game squad for the value reveal (25/26). pos order = pitch rows.
   sums to 58 = "You" squad value in FINAL. name/photo are placeholders. */
const FINAL_SQUAD = [
  { pos: 'ST', name: 'Player 07', photo: null, fin: 12 },
  { pos: 'WF', name: 'Player 11', photo: null, fin: 9 },
  { pos: 'DM', name: 'Player 04', photo: null, fin: 8 },
  { pos: 'AM', name: 'Player 05', photo: null, fin: 14 },
  { pos: 'CB', name: 'Player 02', photo: null, fin: 9 },
  { pos: 'CB', name: 'Player 09', photo: null, fin: 4 },
  { pos: 'GK', name: 'Player 01', photo: null, fin: 2 },
];

/* ---- replacement shelf for a sold CB (priced at that draft year) ---- */
const SHELF = {
  CB: [
    { id: 'r1', pos: 'CB', age: 24, val: 3.0, stats: { PAC: 62, SHO: 26, PAS: 58, DRI: 48, DEF: 78, PHY: 80 } },
    { id: 'r2', pos: 'CB', age: 28, val: 5.5, stats: { PAC: 55, SHO: 24, PAS: 64, DRI: 50, DEF: 85, PHY: 83 } },
    { id: 'r3', pos: 'CB', age: 22, val: 1.8, stats: { PAC: 71, SHO: 30, PAS: 55, DRI: 57, DEF: 72, PHY: 70 } },
  ],
};

/* ---- managers + final standings (profit hidden until reveal) ---- */
const MANAGERS = ['You', 'Marco', 'Jen', 'Kit'];
/* squad value visible first; profit hidden until reveal — and it FLIPS the order:
   Marco leads on squad value, but You win once banked profit lands. */
const FINAL = [
  { nm: 'You', sq: 58, pf: 15 },
  { nm: 'Marco', sq: 64, pf: 1 },
  { nm: 'Jen', sq: 55, pf: 8 },
  { nm: 'Kit', sq: 49, pf: 6 },
];

/* season timeline (10 steps) */
const TIMELINE = [
  { yr: '16/17', t: 'draft GK' }, { yr: '17/18', t: 'draft CB' }, { yr: '18/19', t: 'draft CB' },
  { yr: '19/20', t: 'window' }, { yr: '20/21', t: 'draft DM' }, { yr: '21/22', t: 'draft AM' },
  { yr: '22/23', t: 'draft WF' }, { yr: '23/24', t: 'window' }, { yr: '24/25', t: 'draft ST' },
  { yr: '25/26', t: 'REVEAL' },
];

Object.assign(window, { STAT_KEYS, POS_ORDER, fmtM, tierOf, DRAFT_POOL, SQUAD, FINAL_SQUAD, SHELF, MANAGERS, FINAL, TIMELINE });
