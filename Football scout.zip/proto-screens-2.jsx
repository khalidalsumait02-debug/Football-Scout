/* proto-screens-2.jsx — Window (swipe) · Sale reveal · Replacement · Final */

function useCountUp(target, run, ms = 750) {
  const [v, setV] = React.useState(0);
  React.useEffect(() => {
    if (!run) { setV(0); return; }
    let raf, t0;
    const tick = (t) => {
      if (!t0) t0 = t;
      const k = Math.min(1, (t - t0) / ms);
      const e = 1 - Math.pow(1 - k, 3);
      setV(target * e);
      if (k < 1) raf = requestAnimationFrame(tick);
      else setV(target);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, run]);
  return v;
}

/* ---------------- TRANSFER WINDOW — swipe HOLD / SELL ---------------- */
function WindowScreen({ set, onDone }) {
  const squad = SQUAD;
  const [idx, setIdx] = React.useState(0);
  const [dx, setDx] = React.useState(0);
  const [flying, setFlying] = React.useState(0); // -1 sell, +1 hold
  const decisions = React.useRef({});
  const drag = React.useRef(null);
  const [, force] = React.useState(0);

  const commit = (dir) => {
    const p = squad[idx];
    decisions.current[p.id] = dir > 0 ? 'hold' : 'sell';
    setFlying(dir);
    setTimeout(() => {
      setFlying(0); setDx(0);
      const n = idx + 1;
      setIdx(n);
      if (n >= squad.length) {
        const sold = squad.filter((x) => decisions.current[x.id] === 'sell')
          .map((x) => ({ ...x, profit: +(x.cur - x.buy).toFixed(1) }));
        set({ decisions: { ...decisions.current }, sold });
      }
    }, 300);
  };

  const onDown = (e) => { drag.current = { x: e.clientX }; e.target.setPointerCapture?.(e.pointerId); };
  const onMove = (e) => { if (drag.current) { setDx((e.clientX - drag.current.x) / (window.__scoutScale || 1)); } };
  const onUp = () => {
    if (!drag.current) return;
    const d = dx;
    drag.current = null;
    if (d > 95) commit(1);
    else if (d < -95) commit(-1);
    else setDx(0);
  };

  const done = idx >= squad.length;
  const counts = Object.values(decisions.current);
  const nSell = counts.filter((x) => x === 'sell').length;
  const nHold = counts.filter((x) => x === 'hold').length;

  return (
    <div className="scene">
      <Rail step={4} total={8} phase="Transfer window · HOLD or SELL" />
      <div className="app-body" style={{ display: 'flex', flexDirection: 'column' }}>
        <SceneHead kicker="Values are hidden" title="The Window"
          sub="Swipe right to HOLD, left to SELL — on instinct. You won't see current value until you commit." />

        {!done ? (
          <div className="swipe-stage" style={{ marginTop: 8 }}>
            <div className="hint-l">← sell</div><div className="hint-r">hold →</div>
            {[2, 1, 0].map((off) => {
              const i = idx + off;
              if (i >= squad.length) return null;
              const p = squad[i];
              const top = off === 0;
              const rot = top ? dx / 22 : 0;
              const fly = flying && top ? flying * 520 : 0;
              return (
                <div key={p.id}
                  className={"swipe-card" + (off === 1 ? " behind1" : off === 2 ? " behind2" : "")}
                  style={top ? {
                    transform: `translateX(${dx + fly}px) rotate(${rot}deg)`,
                    transition: flying || !drag.current ? 'transform .3s ease' : 'none', zIndex: 10,
                  } : { zIndex: 10 - off }}
                  onPointerDown={top ? onDown : undefined}
                  onPointerMove={top ? onMove : undefined}
                  onPointerUp={top ? onUp : undefined}
                >
                  {top && <React.Fragment>
                    <div className="verdict sell" style={{ opacity: dx < -20 ? Math.min(1, -dx / 90) : 0 }}>SELL</div>
                    <div className="verdict hold" style={{ opacity: dx > 20 ? Math.min(1, dx / 90) : 0 }}>HOLD</div>
                  </React.Fragment>}
                  <div style={{ pointerEvents: 'none' }}>
                    <PlayerCardFull p={p} value={<span className="masked">€??M</span>} tier="silver" accentStats={false} />
                  </div>
                  {top && <div style={{ textAlign: 'center', marginTop: 10, fontWeight: 700, color: 'var(--ink-2)' }}>
                    Your {p.pos} · player {i + 1} of {squad.length}
                  </div>}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="surf rise" style={{ padding: 22, textAlign: 'center', margin: '10px 0' }}>
            <div className="label-sm">Window closed</div>
            <div style={{ display: 'flex', justifyContent: 'center', gap: 26, margin: '14px 0' }}>
              <div><div className="money" style={{ fontSize: 40, color: 'var(--good)' }}>{nHold}</div><div className="label-sm">held</div></div>
              <div><div className="money" style={{ fontSize: 40, color: 'var(--bad)' }}>{nSell}</div><div className="label-sm">to sell</div></div>
            </div>
            <p style={{ color: 'var(--ink-2)', fontSize: 13, margin: 0 }}>{nSell ? 'Time to see what your sales were really worth.' : 'You held the whole squad — no deals this window.'}</p>
          </div>
        )}
      </div>

      <div className="sticky-foot">
        {!done
          ? <div className="btn-row">
              <button className="btn bad" onClick={() => commit(-1)}>Sell</button>
              <button className="btn good" onClick={() => commit(1)}>Hold</button>
            </div>
          : <button className="btn primary" onClick={onDone}>{nSell ? 'Reveal the deals →' : 'Skip to final →'}</button>}
      </div>
    </div>
  );
}

/* ---------------- SALE REVEAL — animated receipt ---------------- */
function SaleScreen({ S, go }) {
  const sold = S.sold || [];
  const [i, setI] = React.useState(0);
  const [revealed, setRevealed] = React.useState(false);
  const p = sold[i];

  React.useEffect(() => { setRevealed(false); const t = setTimeout(() => setRevealed(true), 450); return () => clearTimeout(t); }, [i]);

  const profit = p ? p.profit : 0;
  const animSold = useCountUp(p ? p.cur : 0, revealed, 600);
  const animProfit = useCountUp(Math.abs(profit), revealed, 750);
  const up = profit >= 0;

  if (!p) return null;

  return (
    <div className="scene">
      <Rail step={5} total={8} phase="Sale reveal" />
      <div className="app-body">
        <SceneHead kicker={`Deal ${i + 1} of ${sold.length}`} title={up ? 'Cha-ching' : 'Ouch'}
          sub="The player you sold blind is unmasked — name, sold price, and the profit you bank toward your final score." />

        <div className="receipt rise" style={{ marginTop: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 6 }}>
            {revealed
              ? <div className="id-reveal" key={'ph' + i}><Photo src={p.photo} size={46} radius={12} /></div>
              : <Silh size={46} />}
            <div>
              <div className="label-sm">Sold</div>
              {revealed
                ? <div className="id-reveal" key={'nm' + i} style={{ marginTop: 4 }}><NamePlate name={p.name} tone="ink" /></div>
                : <div style={{ fontWeight: 700, whiteSpace: 'nowrap', color: 'var(--ink-3)' }}>Identity hidden…</div>}
            </div>
            <span className="pos-badge acc" style={{ marginLeft: 'auto' }}>{p.pos}</span>
          </div>
          <hr className="r-cut" />
          <div className="r-line"><span>Sold for</span><span className="money pop" key={'s' + i}>{fmtM(animSold)}</span></div>
          <div className="r-line"><span>Bought for</span><span className="money">{fmtM(p.buy)}</span></div>
          <hr className="r-cut" />
          <div className="r-profit">
            <span className="lab">Profit banked</span>
            <span className={"big " + (up ? 'money up' : 'money down')} style={{ opacity: revealed ? 1 : 0, transition: 'opacity .3s' }}>
              {up ? '+' : '−'}{fmtM(animProfit)}
            </span>
          </div>
        </div>

        <div className="surf flat" style={{ marginTop: 16, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 22 }}>{up ? '🟢' : '🔴'}</span>
          <span style={{ fontSize: 13, color: 'var(--ink-2)' }}>{up ? 'Bought low, sold high — that gain is locked in even though the player is gone.' : 'Sold below what you paid. The gamble of a hidden-value window.'}</span>
        </div>
      </div>

      <div className="sticky-foot">
        {i < sold.length - 1
          ? <button className="btn primary" onClick={() => setI(i + 1)}>Next deal →</button>
          : <button className="btn primary" onClick={() => go('replace')}>Sign replacements →</button>}
      </div>
    </div>
  );
}

/* ---------------- REPLACEMENT — sold → buy split ---------------- */
function genShelf(pos, around) {
  if (SHELF[pos]) return SHELF[pos];
  const base = around || 5;
  return [0, 1, 2].map((k) => ({
    id: pos + '-g' + k, pos, age: 22 + k * 3,
    val: +(base * (0.6 + k * 0.4)).toFixed(1),
    stats: { PAC: 60 + k * 6, SHO: 50 + k * 8, PAS: 58 + k * 4, DRI: 55 + k * 6, DEF: 70 - k * 5, PHY: 72 + k * 3 },
  }));
}
function ReplaceScreen({ S, go }) {
  const sold = (S.sold && S.sold[0]) || SQUAD[1];
  const shelf = genShelf(sold.pos, sold.buy);
  const [pick, setPick] = React.useState(null);
  return (
    <div className="scene">
      <Rail step={6} total={8} phase="Replacement" />
      <div className="app-body">
        <SceneHead kicker={`Replace your ${sold.pos}`} title="The Shelf"
          sub="Sign from the undrafted prospects of that position's draft year — priced at that year." />

        <div className="surf" style={{ padding: 16, background: 'var(--ink)', color: '#fff', marginBottom: 6 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <Photo src={sold.photo} size={42} radius={11} ring="rgba(255,255,255,.5)" />
            <div><div className="label-sm" style={{ color: 'rgba(255,255,255,.55)' }}>Sold</div><div style={{ fontWeight: 700 }}>{sold.name || 'Your ' + sold.pos}</div></div>
            <div style={{ marginLeft: 'auto', textAlign: 'right' }}>
              <div className="label-sm" style={{ color: 'rgba(255,255,255,.55)' }}>Banked</div>
              <span className="money" style={{ fontSize: 22, color: sold.profit >= 0 ? '#5fe0a6' : '#ff8aa0' }}>{sold.profit >= 0 ? '+' : '−'}{fmtM(Math.abs(sold.profit))}</span>
            </div>
          </div>
        </div>

        <div style={{ textAlign: 'center', fontFamily: 'var(--font-d)', fontWeight: 700, color: 'var(--ink-3)', letterSpacing: 1, margin: '4px 0' }}>↓ SIGN A {sold.pos} ↓</div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {shelf.map((p) => (
            <div key={p.id} onClick={() => setPick(p.id)}
              className={"pcard mini tap-card " + tierOf(p.val)}
              style={pick === p.id ? { boxShadow: '0 0 0 3px var(--acc), var(--shadow-lg)' } : null}>
              <div className="inner">
                <Silh size={44} />
                <div><PosBadge pos={p.pos} /><div style={{ fontSize: 11, color: 'var(--ink-3)', fontWeight: 700, marginTop: 3 }}>age {p.age}</div></div>
                <div style={{ marginLeft: 'auto', textAlign: 'right' }}>
                  <div className="money" style={{ fontSize: 20 }}>{fmtM(p.val)}</div>
                  <div className="label-sm" style={{ fontSize: 9 }}>draft-year price</div>
                </div>
                {pick === p.id && <div className="pill acc" style={{ position: 'absolute', top: 8, right: 8 }}>signing</div>}
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="sticky-foot"><button className="btn primary" disabled={!pick} onClick={() => go('final-inter')}>Confirm signing →</button></div>
    </div>
  );
}

/* ---------------- FINAL REVEAL — podium + scratch standings ---------------- */
function FinalScreen({ go }) {
  // standings sorted by squad value first (the visible number)
  const bySquad = [...FINAL].sort((a, b) => b.sq - a.sq);
  const [scratched, setScratched] = React.useState({}); // nm -> true
  const allScratched = bySquad.every((r) => scratched[r.nm]);
  const [flipped, setFlipped] = React.useState(false);

  const byTotal = [...FINAL].map((r) => ({ ...r, tot: r.sq + r.pf })).sort((a, b) => b.tot - a.tot);
  const order = flipped ? byTotal : bySquad;
  const top3 = byTotal.slice(0, 3);

  return (
    <div className="scene">
      <Rail step={7} total={8} yr="25/26" phase="Final reveal" />
      <div className="app-body">
        <SceneHead kicker="The whistle blows" title="The Reveal"
          sub="Final score = current squad value + every euro of banked profit. Profit lands last — so the table can still flip." />

        <div className="podium" style={{ opacity: flipped ? 1 : .25, transition: 'opacity .5s', filter: flipped ? 'none' : 'grayscale(.6)' }}>
          {[top3[1], top3[0], top3[2]].map((r, k) => r && (
            <div key={r.nm} className={"pod " + (r === top3[0] ? 'p1' : r === top3[1] ? 'p2' : 'p3')}>
              <div className="rk">{r === top3[0] ? 1 : r === top3[1] ? 2 : 3}</div>
              <div className="nm">{r.nm}</div>
              <div className="sc">{fmtM(r.tot)}</div>
            </div>
          ))}
        </div>

        <div className="standings" style={{ marginTop: 14 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '30px 1fr 64px 78px', gap: 8, padding: '0 13px' }} className="label-sm">
            <span></span><span>Manager</span><span style={{ textAlign: 'right' }}>Squad</span><span style={{ textAlign: 'right' }}>+ Profit</span>
          </div>
          {order.map((r, i) => {
            const isYou = r.nm === 'You';
            const sc = scratched[r.nm];
            return (
              <div key={r.nm} className={"srow" + (isYou ? " you" : "")}>
                <span className="rk">{i + 1}</span>
                <span className="nm"><span className="mgr" style={{ width: 26, height: 26, fontSize: 12, background: isYou ? 'var(--acc)' : undefined, color: isYou ? '#fff' : undefined }}>{r.nm[0]}</span>{r.nm}</span>
                <span className="sq">{flipped ? fmtM(r.sq + r.pf) : fmtM(r.sq)}</span>
                <span className="pf">
                  {flipped
                    ? <span className="money up" style={{ fontSize: 14 }}>+{fmtM(r.pf)}</span>
                    : <span className={"scratch" + (sc ? " revealed" : "")} onClick={() => setScratched((s) => ({ ...s, [r.nm]: true }))} style={{ display: 'block', height: 24 }}>
                        <span className="cover">scratch</span>
                        <span className="money up" style={{ fontSize: 14, display: 'flex', alignItems: 'center', justifyContent: 'flex-end', height: '100%' }}>+{fmtM(r.pf)}</span>
                      </span>}
                </span>
              </div>
            );
          })}
        </div>

        <div style={{ textAlign: 'center', marginTop: 14, minHeight: 24 }}>
          {!flipped && !allScratched && <span className="label-sm">Scratch each manager's banked profit →</span>}
          {!flipped && allScratched && <button className="btn primary rise" onClick={() => setFlipped(true)}>Tally final scores →</button>}
          {flipped && <div className="rise"><div className="kicker">Winner</div><div style={{ fontFamily: 'var(--font-d)', fontWeight: 700, fontSize: 32, textTransform: 'uppercase' }}>{byTotal[0].nm} · {fmtM(byTotal[0].sq + byTotal[0].pf)}</div><p style={{ color: 'var(--ink-2)', fontSize: 13 }}>Marco led on squad value — but your banked profit won it.</p></div>}
        </div>
      </div>
      {flipped && <div className="sticky-foot"><button className="btn ghost" onClick={() => go('setup')}>Play again</button></div>}
    </div>
  );
}

Object.assign(window, { WindowScreen, SaleScreen, ReplaceScreen, FinalScreen, useCountUp });
