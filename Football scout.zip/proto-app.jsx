/* proto-app.jsx — scene router, device frame, tweaks */

const ACCENTS = {
  '#1f5bff': { d: '#1442cc', l: '#6f97ff', g: 'rgba(31,91,255,.32)' },   // electric blue
  '#0fae7a': { d: '#0a8a60', l: '#5fd6a8', g: 'rgba(15,174,122,.3)' },   // pitch green
  '#6b4dff': { d: '#4f33d6', l: '#a08cff', g: 'rgba(107,77,255,.32)' },  // violet
  '#ff6a3d': { d: '#e0501f', l: '#ffa382', g: 'rgba(255,106,61,.32)' },  // ember
};

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#1f5bff",
  "foil": true,
  "rail": true
}/*EDITMODE-END*/;

function useScale(w, h, pad = 40) {
  const [scale, setScale] = React.useState(1);
  React.useEffect(() => {
    const fit = () => {
      const s = Math.min(1, (window.innerHeight - pad) / h, (window.innerWidth - 24) / w);
      const v = Math.max(0.4, s);
      window.__scoutScale = v;
      setScale(v);
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, [w, h, pad]);
  return scale;
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [scene, setScene] = React.useState('setup');
  const [S, setS] = React.useState({ drafted: null, decisions: {}, sold: [] });
  const set = (patch) => setS((s) => ({ ...s, ...patch }));
  const go = (k) => { setScene(k); document.querySelector('.app-body')?.scrollTo(0, 0); };
  const scale = useScale(402, 874);

  React.useEffect(() => {
    const a = ACCENTS[t.accent] || ACCENTS['#1f5bff'];
    const r = document.documentElement;
    r.style.setProperty('--acc', t.accent);
    r.style.setProperty('--acc-d', a.d);
    r.style.setProperty('--acc-l', a.l);
    r.style.setProperty('--acc-glow', a.g);
    document.body.classList.toggle('no-foil', !t.foil);
    document.body.classList.toggle('no-rail', !t.rail);
  }, [t]);

  function reset() { setS({ drafted: null, decisions: {}, sold: [] }); go('setup'); }

  let screen;
  switch (scene) {
    case 'setup': screen = <SetupScreen next={() => go('draft')} />; break;
    case 'draft': screen = <DraftScreen S={S} set={set} next={() => go('turn')} />; break;
    case 'turn': screen = <TurnScreen S={S} next={() => go('squad')} />; break;
    case 'squad': screen = <SquadScreen S={S} next={() => go('window-inter')} />; break;
    case 'window-inter': screen = <Interstitial kicker="Time jumps forward" yr="23/24" big="Transfer window" p="Three seasons on, your squad has grown. Now decide who to cash in — blind." cta="Open the window" next={() => go('window')} />; break;
    case 'window': screen = <WindowScreen set={set} onDone={() => go((S.sold && S.sold.length) ? 'sale' : 'final-inter')} />; break;
    case 'sale': screen = <SaleScreen S={S} go={go} />; break;
    case 'replace': screen = <ReplaceScreen S={S} go={go} />; break;
    case 'final-inter': screen = <Interstitial kicker="Final whistle" yr="25/26" big="The Reveal" p="Ten seasons done. Squad value plus every banked profit decides it all." cta="Reveal the table" next={() => go('squad-reveal')} />; break;
    case 'squad-reveal': screen = <SquadRevealScreen next={() => go('final')} />; break;
    case 'final': screen = <FinalScreen go={(k) => (k === 'setup' ? reset() : go(k))} />; break;
    default: screen = <SetupScreen next={() => go('draft')} />;
  }

  return (
    <React.Fragment>
      <div style={{ width: 402 * scale, height: 874 * scale }}>
        <div style={{ width: 402, height: 874, transform: `scale(${scale})`, transformOrigin: 'top left' }}>
          <IOSDevice>
            <div className="app">
              <div className="app-top" />
              {React.cloneElement(screen, { key: scene })}
            </div>
          </IOSDevice>
        </div>
      </div>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Brand" />
        <TweakColor label="Accent" value={t.accent}
          options={Object.keys(ACCENTS)}
          onChange={(v) => setTweak('accent', v)} />
        <TweakSection label="Card finish" />
        <TweakToggle label="Foil sheen" value={t.foil} onChange={(v) => setTweak('foil', v)} />
        <TweakToggle label="Season rail" value={t.rail} onChange={(v) => setTweak('rail', v)} />
        <TweakSection label="Demo" />
        <TweakButton label="Restart playthrough" onClick={reset} />
      </TweaksPanel>
    </React.Fragment>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
