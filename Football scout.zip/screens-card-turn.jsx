/* screens-card-turn.jsx — Anon player card (3) + Whose-turn (2) + Squad view (3) */

/* ---------------- ANONYMOUS PLAYER CARD ---------------- */
function CardMoment() {
  return (
    <div className="variants">
      <Variant badge="A" name="Radar hero" desc="Silhouette + ability radar dominate; numbers secondary. The shape of a player tells the story without a name.">
        <Phone title="Prospect #5" meta="ST · 16/17">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Anon label="?" /><div style={{ flex: 1 }} /><Pos acc>ST</Pos><Chip>age 21</Chip>
          </div>
          <div style={{ height: 150 }}><Radar /></div>
          <Stats acc rows={[{ k: 'PAC', v: 91, hi: true }, { k: 'SHO', v: 84 }, { k: 'DRI', v: 79 }, { k: 'PAS', v: 62 }, { k: 'PHY', v: 55 }]} />
          <div style={{ flex: 1 }} />
          <Box pad={9} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontFamily: 'Space Mono,monospace', fontSize: 9, color: 'var(--ink-soft)' }}>MARKET VALUE</span>
            <span className="money" style={{ fontSize: 18 }}>€18M</span>
          </Box>
          <Btn variant="acc">DRAFT THIS PROSPECT ›</Btn>
        </Phone>
      </Variant>

      <Variant badge="B" name="Dossier / data sheet" desc="A scouting report: dense stat bars, attributes grouped, value boxed at top. For managers who trust the numbers over the vibe.">
        <Phone title="Scout report" meta="anon · ST">
          <Box pad={9} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div><Anon label="?" small /></div>
            <div style={{ textAlign: 'right' }}><span className="money" style={{ fontSize: 17 }}>€18M</span><div style={{ fontFamily: 'Space Mono,monospace', fontSize: 8, color: 'var(--ink-faint)' }}>value</div></div>
          </Box>
          <div style={{ display: 'flex', gap: 6 }}><Chip>21 yrs</Chip><Chip>R foot</Chip><Chip acc>ST</Chip></div>
          <div className="scrim" style={{ flex: 1, overflow: 'hidden' }}>
            <Stats acc rows={[{ k: 'PAC', v: 91, hi: true }, { k: 'ACC', v: 88 }, { k: 'SHO', v: 84 }, { k: 'FIN', v: 86 }, { k: 'DRI', v: 79 }, { k: 'PAS', v: 62 }, { k: 'PHY', v: 55 }, { k: 'DEF', v: 24 }]} />
            <div className="more" />
          </div>
          <Btn variant="primary">DRAFT ›</Btn>
        </Phone>
      </Variant>

      <Variant badge="C" name="Minimal poster" desc="One huge value number, one signature stat, lots of air. Mystery-forward — almost no data, all gut feel. Boldest direction.">
        <Phone meta="">
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: 14, textAlign: 'center' }}>
            <Anon label="?" />
            <Pos acc>ST</Pos>
            <div>
              <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 9, color: 'var(--ink-faint)' }}>MARKET VALUE</div>
              <div className="reveal-num" style={{ fontSize: 44 }}>€18M</div>
            </div>
            <Annot note="signature stat only — PACE 91">one stat to seduce you</Annot>
          </div>
          <div style={{ display: 'flex', gap: 8 }}><Btn variant="ghost">stats ▾</Btn><Btn variant="acc">DRAFT</Btn></div>
        </Phone>
      </Variant>
      <Annot note="No name, no club, no face. Value + stats only. The whole game lives or dies on this card.">No name. No club. No face.</Annot>
    </div>
  );
}

/* ---------------- WHOSE TURN / PICK CONFIRM ---------------- */
function TurnMoment() {
  return (
    <div className="variants">
      <Variant badge="A" name="Snake order banner" desc="Persistent draft-order strip; your avatar pulses on your turn, drafted picks grey out. Always answers 'is it me yet?'.">
        <Phone title="Draft · ST" meta="round 1">
          <Box pad={10}>
            <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 9, color: 'var(--ink-soft)', marginBottom: 7 }}>PICK ORDER (snake)</div>
            <Snake mgrs={MGRS} now={2} done={[0, 1]} />
            <div style={{ textAlign: 'center', marginTop: 12, fontFamily: 'Caveat,cursive', fontSize: 26, color: 'var(--accent-ink)' }}>Jen is picking…</div>
          </Box>
          <Dash label="board dims while you wait" style={{ flex: 1 }} />
          <Annot className="arrow-l">order reverses each round so nobody hoards value</Annot>
        </Phone>
      </Variant>

      <Variant badge="B" name="Your turn takeover" desc="Full-screen interrupt the moment it's you, with a pick timer. Removes 'whose turn?' confusion entirely; raises the pressure.">
        <Phone meta="">
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: 16, textAlign: 'center' }}>
            <div className="mgr now" style={{ width: 64, height: 64, fontSize: 26 }}>A</div>
            <div style={{ fontFamily: 'Caveat,cursive', fontSize: 40, lineHeight: .9 }}>YOUR PICK</div>
            <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 11, color: 'var(--ink-soft)' }}>striker · 4 prospects left</div>
            <Box pad={10} style={{ width: 120, textAlign: 'center' }}><span className="reveal-num" style={{ fontSize: 28 }}>0:24</span><div style={{ fontFamily: 'Space Mono,monospace', fontSize: 8, color: 'var(--ink-faint)' }}>to pick</div></Box>
          </div>
          <Btn variant="primary">GO TO BOARD ›</Btn>
        </Phone>
      </Variant>
      <Annot note="Drafted prospects must visibly LEAVE the board — grey out + slide away so scarcity is felt.">Drafted prospects leave the board.</Annot>
    </div>
  );
}

/* ---------------- SQUAD VIEW ---------------- */
const FORM = [['GK'], ['CB', 'CB'], ['DM'], ['AM'], ['WF', 'ST']];
function SquadMoment() {
  return (
    <div className="variants">
      <Variant badge="A" name="Formation pitch" desc="Your 7 slots laid on a pitch by role. Empty slots = positions not yet drafted, so the squad literally fills in across seasons.">
        <Phone title="My squad" meta="5 / 7 filled">
          <div className="pitch">
            {FORM.map((row, ri) => (
              <div className="row" key={ri}>
                {row.map((p, ci) => (
                  <div key={ci} className={"pp" + (ri < 3 || (ri === 4 && ci === 1) ? " acc" : "")} style={ri === 3 || (ri === 4 && ci === 0) ? { borderStyle: 'dashed', color: 'var(--ink-faint)' } : {}}>{p}</div>
                ))}
              </div>
            ))}
          </div>
          <div className="legend"><span><span className="pp acc" style={{ width: 16, height: 16 }} /> drafted</span><span><span className="pp" style={{ width: 16, height: 16, borderStyle: 'dashed' }} /> open</span></div>
        </Phone>
      </Variant>

      <Variant badge="B" name="Roster list + total" desc="Position rows with current value and a running squad total at the bottom — the number you're trying to grow. Numbers-forward.">
        <Phone title="My squad" meta="value €54M">
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 6 }}>
            {[['GK', '€7M', 1], ['CB', '€9M', 1], ['CB', '€4M', 1], ['DM', '—', 0], ['AM', '€21M', 1], ['WF', '—', 0], ['ST', '€13M', 1]].map((r, i) => (
              <Box key={i} pad={7} style={r[2] ? {} : { borderStyle: 'dashed' }}>
                <div className="lrow" style={{ padding: 0, justifyContent: 'space-between' }}>
                  <span style={{ display: 'flex', gap: 8, alignItems: 'center' }}><Pos acc={!!r[2]}>{r[0]}</Pos>{r[2] ? <Anon label="?" small /> : <span className="who" style={{ fontFamily: 'Space Mono,monospace', fontSize: 9 }}>drafts later</span>}</span>
                  <span className="money">{r[1]}</span>
                </div>
              </Box>
            ))}
          </div>
          <Box pad={9} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'var(--ink)', color: 'var(--paper)' }}>
            <span style={{ fontFamily: 'Space Mono,monospace', fontSize: 10 }}>SQUAD VALUE</span><span className="money" style={{ fontSize: 16 }}>€54M</span>
          </Box>
        </Phone>
      </Variant>

      <Variant badge="C" name="Value bars" desc="Each player a horizontal bar scaled to value, so the squad's shape and your big assets read instantly. Doubles as the scoring mental model.">
        <Phone title="My squad" meta="by value">
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 9, justifyContent: 'center' }}>
            {[['AM', 92], ['ST', 60], ['CB', 42], ['GK', 33], ['CB', 19]].map((r, i) => (
              <div key={i}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'Space Mono,monospace', fontSize: 9, marginBottom: 3 }}><span><Pos acc>{r[0]}</Pos></span><span className="money">{['€21M', '€13M', '€9M', '€7M', '€4M'][i]}</span></div>
                <div className="bar" style={{ height: 12, border: '1.5px solid var(--ink)', borderRadius: 6, background: 'var(--paper-2)', overflow: 'hidden' }}><i style={{ display: 'block', height: '100%', width: r[1] + '%', background: 'var(--accent)' }} /></div>
              </div>
            ))}
            <div className="lrow" style={{ padding: 0, opacity: .5 }}><Pos>DM</Pos><Pos>WF</Pos><span className="who" style={{ fontFamily: 'Space Mono,monospace', fontSize: 9 }}>not drafted yet</span></div>
          </div>
        </Phone>
      </Variant>
    </div>
  );
}

Object.assign(window, { CardMoment, TurnMoment, SquadMoment });
