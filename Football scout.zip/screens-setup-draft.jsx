/* screens-setup-draft.jsx — Home/setup + the core Draft Board (4 approaches) */

const MGRS = ['A', 'M', 'J', 'K'];

/* ---------------- HOME / SETUP ---------------- */
function HomeMoment() {
  return (
    <div className="variants">
      <Variant badge="A" name="Cover + roster" desc="Big title, add managers as rows, one START button. Reads like a board-game box lid.">
        <Phone>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 12, paddingTop: 10 }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontFamily: 'Caveat,cursive', fontSize: 46, lineHeight: .9 }}>THE SCOUT</div>
              <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 10, color: 'var(--ink-faint)' }}>7 drafts · 2 windows · 1 reveal</div>
            </div>
            <Dash label="cover art / crest" style={{ height: 92 }} />
            <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 10, color: 'var(--ink-soft)' }}>MANAGERS</div>
            {['You', 'Marco', 'Jen', '+ add manager'].map((m, i) => (
              <Box key={i} pad={8} className={i === 3 ? '' : ''} style={i === 3 ? { borderStyle: 'dashed', color: 'var(--ink-faint)' } : {}}>
                <div className="lrow" style={{ padding: 0 }}>
                  <span className="dot fill" /><span style={{ fontFamily: 'Patrick Hand,cursive', fontSize: 15 }}>{m}</span>
                </div>
              </Box>
            ))}
            <div style={{ flex: 1 }} />
            <Btn variant="primary">START SEASON 16/17 ›</Btn>
          </div>
        </Phone>
      </Variant>

      <Variant badge="B" name="Timeline lobby" desc="Shows the whole 10-step journey up front so players grasp the arc before picking. Tap to begin.">
        <Phone title="New game" meta="2016 → 2026">
          <Dash label="league backdrop" style={{ height: 60 }} />
          <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 10, color: 'var(--ink-soft)' }}>THE 10 STEPS</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {[['16/17', 'draft GK'], ['17/18', 'draft CB'], ['18/19', 'draft CB'], ['19/20', 'transfer window'], ['20/21', 'draft DM'], ['…', '…'], ['25/26', 'FINAL REVEAL']].map((s, i) => (
              <div key={i} className="lrow" style={{ padding: '3px 4px', borderLeft: '2px solid var(--ink)' }}>
                <span className="pos" style={{ minWidth: 44 }}>{s[0]}</span>
                <span style={{ fontFamily: 'Space Mono,monospace', fontSize: 11, color: i === 6 ? 'var(--accent-ink)' : 'var(--ink-soft)' }}>{s[1]}</span>
              </div>
            ))}
          </div>
          <div style={{ flex: 1 }} />
          <Btn variant="acc">CHOOSE MANAGERS ›</Btn>
        </Phone>
      </Variant>
      <Annot note="Setup is low-stakes — keep it to ONE screen. The journey arc (B) sets expectations for the long game.">Setup is low-stakes — keep it to one screen.</Annot>
    </div>
  );
}

/* ---------------- DRAFT BOARD (the core) ---------------- */
const DRAFT_VAL = ['€4.2M', '€11M', '€6.8M', '€2.1M', '€18M'];
const DRAFT_AGE = [19, 27, 23, 31, 21];

function MiniCard({ i, compact }) {
  return (
    <Box pad={8} style={{ position: 'relative' }}>
      <div className="lrow" style={{ padding: 0, justifyContent: 'space-between' }}>
        <Anon label="?" small />
        <div style={{ textAlign: 'right' }}>
          <Pos acc>ST</Pos>
          <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 9, color: 'var(--ink-faint)', marginTop: 3 }}>age {DRAFT_AGE[i]}</div>
        </div>
      </div>
      {!compact && (
        <div style={{ marginTop: 7 }}>
          <Stats acc rows={[{ k: 'PAC', v: [70, 55, 82, 48, 91][i], hi: true }, { k: 'SHO', v: [61, 80, 66, 88, 84][i] }, { k: 'PHY', v: [58, 84, 60, 79, 55][i] }]} />
        </div>
      )}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 }}>
        <span className="money">{DRAFT_VAL[i]}</span>
        <span className="chip acc">DRAFT</span>
      </div>
    </Box>
  );
}

function DraftMoment() {
  return (
    <div className="variants">
      {/* A — scroll list */}
      <Variant badge="A" name="Scroll list" desc="Vertical feed of all 5 cards, key stats inline. Fast to skim; market value bottom-right. Safest, most legible.">
        <Phone title="Draft · ST" meta={'pick 2 of 4'}>
          <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 9.5, color: 'var(--ink-soft)' }}>ORDER</div>
          <Snake mgrs={MGRS} now={1} done={[0]} />
          <div className="scrim" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 9, overflow: 'hidden' }}>
            <MiniCard i={4} /><MiniCard i={1} /><MiniCard i={0} />
            <div className="more" />
          </div>
        </Phone>
      </Variant>

      {/* B — grid + radar */}
      <Variant badge="B" name="2-up grid + radar" desc="Compact tiles with a shape-glance radar. Visual scouts compare silhouettes of ability fast. Tap a tile for detail.">
        <Phone title="Draft · ST" meta="5 prospects">
          <Snake mgrs={MGRS} now={1} done={[0]} />
          <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, overflow: 'hidden' }}>
            {[4, 1, 0, 2].map((i) => (
              <Box key={i} pad={7}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Pos acc>ST</Pos><span style={{ fontFamily: 'Space Mono,monospace', fontSize: 8, color: 'var(--ink-faint)' }}>#{i + 1}</span>
                </div>
                <div style={{ height: 58, margin: '5px 0' }}><Radar /></div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span className="money" style={{ fontSize: 11 }}>{DRAFT_VAL[i]}</span>
                  <span className="dot acc" />
                </div>
              </Box>
            ))}
          </div>
          <Btn variant="acc">DRAFT SELECTED ›</Btn>
        </Phone>
      </Variant>

      {/* C — swipe deck */}
      <Variant badge="C" name="Swipe deck" desc="One hero card at a time, deck stacked behind. Swipe to browse, swipe up to draft. Maximises the mystery of each prospect.">
        <Phone title="Draft · ST" meta="card 3 / 5">
          <Snake mgrs={MGRS} now={1} done={[0]} />
          <div style={{ flex: 1, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Box pad={0} style={{ position: 'absolute', inset: '14px 26px', transform: 'rotate(4deg)', opacity: .35 }} />
            <Box pad={0} style={{ position: 'absolute', inset: '10px 18px', transform: 'rotate(-3deg)', opacity: .55 }} />
            <Box pad={12} style={{ position: 'absolute', inset: '4px 8px', display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}><Anon label="?" /><Pos acc>ST</Pos></div>
              <div style={{ height: 70 }}><Radar /></div>
              <Stats acc rows={[{ k: 'PAC', v: 82, hi: true }, { k: 'SHO', v: 66 }, { k: 'PAS', v: 59 }, { k: 'DRI', v: 74 }]} />
              <div style={{ flex: 1 }} />
              <div style={{ textAlign: 'center' }}><span className="money" style={{ fontSize: 16 }}>€6.8M</span></div>
            </Box>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <Btn variant="ghost">‹ skip</Btn><Btn variant="acc">↑ DRAFT</Btn>
          </div>
        </Phone>
      </Variant>

      {/* D — compare matrix */}
      <Variant badge="D" name="Compare matrix" desc="All 5 in a stat table, best value highlighted per row. For the spreadsheet manager who wants cold comparison, not vibes.">
        <Phone title="Draft · ST" meta="compare">
          <Box pad={6}>
            <div style={{ display: 'grid', gridTemplateColumns: '40px repeat(5,1fr)', gap: 4, fontFamily: 'Space Mono,monospace', fontSize: 8.5 }}>
              <span style={{ color: 'var(--ink-faint)' }}></span>
              {['1', '2', '3', '4', '5'].map((h) => <span key={h} style={{ textAlign: 'center', fontWeight: 700 }}>{h}</span>)}
              {[['AGE', DRAFT_AGE, 0], ['PAC', [70, 55, 82, 48, 91], 4], ['SHO', [61, 80, 66, 88, 84], 3], ['PHY', [58, 84, 60, 79, 55], 1], ['€M', [4.2, 11, 6.8, 2.1, 18], 3]].map((r, ri) => (
                <React.Fragment key={ri}>
                  <span style={{ color: 'var(--ink-soft)' }}>{r[0]}</span>
                  {r[1].map((v, ci) => (
                    <span key={ci} style={{ textAlign: 'center', fontWeight: 700, background: ci === r[2] ? 'var(--hi)' : 'transparent', borderRadius: 3, color: 'var(--ink)' }}>{v}</span>
                  ))}
                </React.Fragment>
              ))}
            </div>
          </Box>
          <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 8.5, color: 'var(--ink-faint)' }}>tap a column to draft that prospect</div>
          <div style={{ display: 'flex', gap: 6 }}>
            {[1, 2, 3, 4, 5].map((n) => <div key={n} className="mgr" style={{ flex: 1, borderRadius: 6, width: 'auto', height: 30 }}>{n}</div>)}
          </div>
          <div style={{ flex: 1 }} />
          <Annot className="arrow-l">value is a stat too — they pick blind on numbers</Annot>
          <Btn variant="primary">DRAFT COLUMN 5 ›</Btn>
        </Phone>
      </Variant>
    </div>
  );
}

Object.assign(window, { HomeMoment, DraftMoment, MGRS });
