/* screens-transfer-final.jsx — Transfer window (3) + Replacement (2) + Sale reveal (3) + Final (3) */

/* ---------------- TRANSFER WINDOW: HOLD or SELL ---------------- */
function WindowMoment() {
  return (
    <div className="variants">
      <Variant badge="A" name="Swipe verdict" desc="One player at a time: swipe right HOLD, left SELL. Values are hidden (€???), so it's a pure read on whether they've grown. Tense & tactile.">
        <Phone title="Window 19/20" meta="player 2 / 5">
          <div style={{ flex: 1, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Box pad={12} style={{ position: 'absolute', inset: '6px 10px', display: 'flex', flexDirection: 'column', gap: 9 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}><Anon label="?" /><Pos acc>CB</Pos></div>
              <div style={{ height: 64 }}><Radar /></div>
              <Box pad={8} style={{ textAlign: 'center', borderStyle: 'dashed' }}><span style={{ fontFamily: 'Space Mono,monospace', fontSize: 9, color: 'var(--ink-faint)' }}>CURRENT VALUE</span><div className="val hidden-v" style={{ fontSize: 22 }}>€ ? ? ?</div></Box>
            </Box>
            <div style={{ position: 'absolute', left: 6, top: '46%', fontFamily: 'Caveat,cursive', fontSize: 20, color: 'var(--bad)', transform: 'rotate(-8deg)' }}>‹ SELL</div>
            <div style={{ position: 'absolute', right: 6, top: '46%', fontFamily: 'Caveat,cursive', fontSize: 20, color: 'var(--good)', transform: 'rotate(8deg)' }}>HOLD ›</div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}><Btn variant="sell">SELL</Btn><Btn variant="hold">HOLD</Btn></div>
        </Phone>
      </Variant>

      <Variant badge="B" name="Toggle roster" desc="Whole squad on one screen, each row a HOLD/SELL switch. See all decisions at once and commit together. Values stay masked.">
        <Phone title="Transfer window" meta="19/20">
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 7 }}>
            {[['GK', 'hold'], ['CB', 'sell'], ['CB', 'hold'], ['DM', 'hold'], ['AM', 'hold'], ['WF', 'sell'], ['ST', 'hold']].map((r, i) => (
              <Box key={i} pad={7}>
                <div className="lrow" style={{ padding: 0, justifyContent: 'space-between' }}>
                  <span style={{ display: 'flex', gap: 7, alignItems: 'center' }}><Pos acc>{r[0]}</Pos><span className="val hidden-v" style={{ fontSize: 11 }}>€???</span></span>
                  <span style={{ display: 'flex', gap: 4 }}>
                    <span className="chip" style={r[1] === 'hold' ? { background: 'var(--good)', color: '#fff', borderColor: 'var(--good)' } : {}}>HOLD</span>
                    <span className="chip" style={r[1] === 'sell' ? { background: 'var(--bad)', color: '#fff', borderColor: 'var(--bad)' } : {}}>SELL</span>
                  </span>
                </div>
              </Box>
            ))}
          </div>
          <Btn variant="primary">CONFIRM 5 HOLD · 2 SELL ›</Btn>
        </Phone>
      </Variant>

      <Variant badge="C" name="Two-pile sort" desc="Drag cards into a KEEP pile or a SELL pile. Physical, board-game feel; the growing sell pile makes the gamble visceral.">
        <Phone title="Sort your squad" meta="drag to decide">
          <div style={{ flex: 1, display: 'grid', gridTemplateRows: '1fr 1fr', gap: 10 }}>
            <Box pad={8} style={{ borderColor: 'var(--good)' }}>
              <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 9, color: 'var(--good)', marginBottom: 6 }}>KEEP</div>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>{['GK', 'CB', 'DM', 'AM', 'ST'].map((p, i) => <Pos key={i} acc>{p}</Pos>)}</div>
            </Box>
            <Box pad={8} style={{ borderColor: 'var(--bad)', borderStyle: 'dashed' }}>
              <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 9, color: 'var(--bad)', marginBottom: 6 }}>SELL ↓ drop here</div>
              <div style={{ display: 'flex', gap: 6 }}><Pos>CB</Pos><Pos>WF</Pos></div>
            </Box>
          </div>
          <Annot className="arrow-l">you sell on instinct — true value hidden till you commit</Annot>
        </Phone>
      </Variant>
      <Annot note="THE rule: values hidden during the window. You HOLD/SELL on gut + memory of draft-day stats.">Values stay hidden — sell on instinct.</Annot>
    </div>
  );
}

/* ---------------- REPLACEMENT PICKER ---------------- */
function ReplaceMoment() {
  return (
    <div className="variants">
      <Variant badge="A" name="Leftovers shelf" desc="After selling, pick a replacement from that position's undrafted prospects, priced at that draft year. Year stamp makes the time-travel rule clear.">
        <Phone title="Replace CB" meta="from 17/18 pool">
          <Annot note="priced at 17/18 — when this slot was drafted" className="">vintage prices</Annot>
          <div className="scrim" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8, overflow: 'hidden' }}>
            {[['€3.0M', 24], ['€5.5M', 28], ['€1.8M', 22]].map((r, i) => (
              <Box key={i} pad={8}>
                <div className="lrow" style={{ padding: 0, justifyContent: 'space-between' }}>
                  <span style={{ display: 'flex', gap: 8, alignItems: 'center' }}><Anon label="?" small /><span><Pos acc>CB</Pos> <span style={{ fontFamily: 'Space Mono,monospace', fontSize: 8, color: 'var(--ink-faint)' }}>age {r[1]}</span></span></span>
                  <span style={{ textAlign: 'right' }}><span className="money" style={{ fontSize: 12 }}>{r[0]}</span><div style={{ fontFamily: 'Space Mono,monospace', fontSize: 7, color: 'var(--ink-faint)' }}>'17/18 price</div></span>
                </div>
              </Box>
            ))}
            <div className="more" />
          </div>
          <Btn variant="acc">BUY REPLACEMENT ›</Btn>
        </Phone>
      </Variant>

      <Variant badge="B" name="Sold → Buy split" desc="Top half shows who you just sold (sale price revealed here); bottom half is the replacement shelf. Cause-and-effect on one screen.">
        <Phone title="CB swap" meta="19/20">
          <Box pad={9} style={{ background: 'var(--ink)', color: 'var(--paper)' }}>
            <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 9, opacity: .7 }}>SOLD</div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><Anon label="?" small /><span className="money" style={{ fontSize: 16, color: '#fff' }}>€8.4M</span></div>
          </Box>
          <div style={{ textAlign: 'center', fontFamily: 'Caveat,cursive', fontSize: 22 }}>↓ now buy a CB ↓</div>
          <div className="scrim" style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 7, overflow: 'hidden' }}>
            {['€3.0M', '€5.5M', '€1.8M'].map((p, i) => (
              <Box key={i} pad={7}><div className="lrow" style={{ padding: 0, justifyContent: 'space-between' }}><span style={{ display: 'flex', gap: 7, alignItems: 'center' }}><Anon label="?" small /><Pos acc>CB</Pos></span><span className="money" style={{ fontSize: 12 }}>{p}</span></div></Box>
            ))}
            <div className="more" />
          </div>
        </Phone>
      </Variant>
    </div>
  );
}

/* ---------------- SALE REVEAL ---------------- */
function SaleMoment() {
  return (
    <div className="variants">
      <Variant badge="A" name="Receipt reveal" desc="Sold price, original buy price, and profit stack like a till receipt. Profit lands last in big green/red. Clean, satisfying math.">
        <Phone title="Deal done" meta="CB sold">
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 10 }}>
            <Box pad={11}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'Space Mono,monospace', fontSize: 12, marginBottom: 6 }}><span style={{ color: 'var(--ink-soft)' }}>sold for</span><span className="money">€8.4M</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'Space Mono,monospace', fontSize: 12 }}><span style={{ color: 'var(--ink-soft)' }}>bought for</span><span className="money">€4.0M</span></div>
              <div style={{ borderTop: '2px dashed var(--ink)', margin: '9px 0' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><span style={{ fontFamily: 'Space Mono,monospace', fontSize: 11, color: 'var(--ink-soft)' }}>PROFIT</span><span className="money up reveal-num" style={{ fontSize: 26 }}>+€4.4M</span></div>
            </Box>
            <Annot note="profit banks toward your final score — gone from the squad, kept on the books">banked!</Annot>
          </div>
          <Btn variant="primary">CONTINUE ›</Btn>
        </Phone>
      </Variant>

      <Variant badge="B" name="Scratch to reveal" desc="Sale + buy shown; profit hidden under a scratch panel you swipe off. Maximises the gamble payoff moment — could be a loss.">
        <Phone title="…and the profit?" meta="">
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: 14 }}>
            <div style={{ display: 'flex', gap: 18 }}>
              <div style={{ textAlign: 'center' }}><div style={{ fontFamily: 'Space Mono,monospace', fontSize: 8, color: 'var(--ink-faint)' }}>SOLD</div><span className="money">€8.4M</span></div>
              <div style={{ textAlign: 'center' }}><div style={{ fontFamily: 'Space Mono,monospace', fontSize: 8, color: 'var(--ink-faint)' }}>BOUGHT</div><span className="money">€4.0M</span></div>
            </div>
            <div className="scratch" style={{ width: 150, height: 54, borderRadius: 8 }} />
            <Annot className="arrow-l">swipe to reveal profit — or a loss</Annot>
          </div>
          <Btn variant="acc">SCRATCH ›</Btn>
        </Phone>
      </Variant>

      <Variant badge="C" name="Loss case" desc="Same layout must handle a bad sell: red profit, deflating microcopy. Important that the UI doesn't only celebrate — the gamble can sting.">
        <Phone title="Ouch." meta="WF sold">
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 10 }}>
            <Box pad={11}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'Space Mono,monospace', fontSize: 12, marginBottom: 6 }}><span style={{ color: 'var(--ink-soft)' }}>sold for</span><span className="money">€2.6M</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'Space Mono,monospace', fontSize: 12 }}><span style={{ color: 'var(--ink-soft)' }}>bought for</span><span className="money">€6.0M</span></div>
              <div style={{ borderTop: '2px dashed var(--ink)', margin: '9px 0' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><span style={{ fontFamily: 'Space Mono,monospace', fontSize: 11, color: 'var(--ink-soft)' }}>PROFIT</span><span className="money down reveal-num" style={{ fontSize: 26 }}>−€3.4M</span></div>
            </Box>
            <div style={{ textAlign: 'center', fontFamily: 'Caveat,cursive', fontSize: 20, color: 'var(--bad)' }}>sold a future star too early…</div>
          </div>
          <Btn variant="primary">CONTINUE ›</Btn>
        </Phone>
      </Variant>
    </div>
  );
}

/* ---------------- FINAL REVEAL / SCOREBOARD ---------------- */
function FinalMoment() {
  return (
    <div className="variants">
      <Variant badge="A" name="Two-part tally" desc="Squad value revealed first, banked profit second, then they sum into the final score. Honours the rule that profit lands last for suspense.">
        <Phone title="Final · 25/26" meta="manager: You">
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 9 }}>
            <Box pad={10} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><span style={{ fontFamily: 'Space Mono,monospace', fontSize: 10, color: 'var(--ink-soft)' }}>SQUAD VALUE</span><span className="money" style={{ fontSize: 18 }}>€61M</span></Box>
            <Box pad={10} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><span style={{ fontFamily: 'Space Mono,monospace', fontSize: 10, color: 'var(--ink-soft)' }}>BANKED PROFIT</span><span className="money up" style={{ fontSize: 18 }}>+€12M</span></Box>
            <div style={{ borderTop: '3px solid var(--ink)' }} />
            <Box pad={12} style={{ background: 'var(--hi)', textAlign: 'center' }}><div style={{ fontFamily: 'Space Mono,monospace', fontSize: 9, color: 'var(--ink-soft)' }}>FINAL SCORE</div><div className="reveal-num" style={{ fontSize: 38 }}>€73M</div></Box>
          </div>
          <Btn variant="primary">SEE STANDINGS ›</Btn>
        </Phone>
      </Variant>

      <Variant badge="B" name="Podium standings" desc="All managers ranked. Profit column revealed last (still scratched here) so the leader can flip on the final number. Built for a table-side gasp.">
        <Phone title="STANDINGS" meta="25/26">
          <div className="podium" style={{ marginTop: 4 }}>
            <div className="pod g2"><div className="rk">2</div><span className="money" style={{ fontSize: 9 }}>€68M</span></div>
            <div className="pod g1"><div className="rk">1</div><span className="money" style={{ fontSize: 9 }}>€73M</span></div>
            <div className="pod g3"><div className="rk">3</div><span className="money" style={{ fontSize: 9 }}>€59M</span></div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 6 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 54px 54px', fontFamily: 'Space Mono,monospace', fontSize: 8, color: 'var(--ink-faint)' }}><span>MANAGER</span><span style={{ textAlign: 'right' }}>SQUAD</span><span style={{ textAlign: 'right' }}>+PROFIT</span></div>
            {[['You', '€61M'], ['Marco', '€60M'], ['Jen', '€51M'], ['Kit', '€48M']].map((r, i) => (
              <Box key={i} pad={6}><div style={{ display: 'grid', gridTemplateColumns: '1fr 54px 54px', alignItems: 'center', fontFamily: 'Space Mono,monospace', fontSize: 10 }}><span style={{ display: 'flex', gap: 6, alignItems: 'center' }}><span className="mgr" style={{ width: 18, height: 18, fontSize: 8 }}>{r[0][0]}</span>{r[0]}</span><span style={{ textAlign: 'right' }} className="money">{r[1]}</span><span className="scratch" style={{ height: 14, borderRadius: 3, marginLeft: 8 }} /></div></Box>
            ))}
          </div>
          <Annot className="arrow-l">profit column scratched off — reveal row by row</Annot>
        </Phone>
      </Variant>

      <Variant badge="C" name="Winner takeover" desc="After the reveal, a full-screen winner moment with the breakdown beneath. The celebratory full stop to a 10-step game.">
        <Phone meta="">
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: 12, textAlign: 'center' }}>
            <div style={{ fontFamily: 'Caveat,cursive', fontSize: 24 }}>🏆 winner</div>
            <div className="mgr now" style={{ width: 60, height: 60, fontSize: 24 }}>A</div>
            <div style={{ fontFamily: 'Caveat,cursive', fontSize: 40, lineHeight: .9 }}>You</div>
            <div className="reveal-num" style={{ fontSize: 40 }}>€73M</div>
            <div style={{ fontFamily: 'Space Mono,monospace', fontSize: 10, color: 'var(--ink-soft)' }}>€61M squad + €12M banked</div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}><Btn variant="ghost">recap</Btn><Btn variant="acc">play again</Btn></div>
        </Phone>
      </Variant>
      <Annot note="Scoring = final squad value + cumulative banked profit. Reveal profit LAST so standings can flip.">Profit revealed last — the leader can still flip.</Annot>
    </div>
  );
}

Object.assign(window, { WindowMoment, ReplaceMoment, SaleMoment, FinalMoment });
