/* proto-screens-1.jsx — Setup · Draft (+Dossier) · Turn · Squad · Interstitial */

/* ---------------- SETUP ---------------- */
function SetupScreen({ next }) {
  const [mgrs] = React.useState(['You', 'Marco', 'Jen', 'Kit']);
  return (
    <div className="scene">
      <Rail step={0} total={8} yr="16/17" phase="New game" />
      <div className="app-body">
        <div className="center-col" style={{ paddingTop: 18, flex: 'none', gap: 6 }}>
          <div className="kicker">A hidden-value scouting game</div>
          <div style={{ fontFamily: 'var(--font-d)', fontWeight: 700, fontSize: 56, lineHeight: .86, letterSpacing: .5, textTransform: 'uppercase' }}>The<br />Scout</div>
          <div className="label-sm" style={{ marginTop: 4 }}>7 drafts · 2 windows · 1 reveal</div>
        </div>

        <div style={{ margin: '20px 0 6px' }} className="label-sm">Managers · {mgrs.length}</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
          {mgrs.map((m, i) => (
            <div key={i} className="surf" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px' }}>
              <div className="mgr" style={{ background: i === 0 ? 'var(--acc)' : undefined, color: i === 0 ? '#fff' : undefined, boxShadow: i === 0 ? '0 4px 12px var(--acc-glow)' : undefined }}>{m[0]}</div>
              <span style={{ fontWeight: 700, fontSize: 16 }}>{m}</span>
              {i === 0 && <span className="pill acc" style={{ marginLeft: 'auto' }}>you</span>}
            </div>
          ))}
          <div className="surf flat" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', color: 'var(--ink-3)', fontWeight: 700, fontSize: 15 }}>
            <div className="mgr" style={{ boxShadow: 'inset 0 0 0 1.5px var(--line-2)' }}>+</div> Add manager
          </div>
        </div>
      </div>
      <div className="sticky-foot"><button className="btn primary" onClick={next}>Start season 16/17 →</button></div>
    </div>
  );
}

/* ---------------- DRAFT BOARD + DOSSIER ---------------- */
function DraftScreen({ S, set, next }) {
  const [taken, setTaken] = React.useState({});      // id -> true
  const [leaving, setLeaving] = React.useState(null); // id animating out
  const [open, setOpen] = React.useState(null);       // dossier player
  const [drafted, setDrafted] = React.useState(false);

  function confirmDraft(p) {
    setOpen(null);
    setLeaving(p.id);
    setTimeout(() => {
      setTaken((t) => ({ ...t, [p.id]: 'you' }));
      setLeaving(null);
      set({ drafted: p });
      // AI managers grab two others
      const others = DRAFT_POOL.filter((x) => x.id !== p.id).map((x) => x.id);
      setTimeout(() => setTaken((t) => ({ ...t, [others[3]]: 'ai' })), 360);
      setTimeout(() => setTaken((t) => ({ ...t, [others[1]]: 'ai' })), 760);
      setTimeout(() => setDrafted(true), 1050);
    }, 480);
  }

  const pickedBy = (id) => taken[id];

  return (
    <div className="scene">
      <Rail step={1} total={8} yr="24/25" phase="Draft · ST" />
      <div className="app-body">
        <SceneHead kicker="Striker slot open" title="The Board"
          sub="Five anonymous prospects. Stats and market value only — no names. Tap a card to scout it." />

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '2px 2px 12px' }}>
          <span className="label-sm">Pick order</span>
          <Snake now={drafted ? null : 0} done={drafted ? [0] : []} />
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
          {DRAFT_POOL.map((p) => (
            <PlayerCardMini key={p.id} p={p}
              taken={!!pickedBy(p.id)}
              leaving={leaving === p.id}
              onClick={drafted ? undefined : () => setOpen(p)} />
          ))}
        </div>

        {drafted && (
          <div className="surf rise" style={{ marginTop: 16, padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12, boxShadow: '0 0 0 2px var(--acc), var(--shadow)' }}>
            <Silh size={40} />
            <div>
              <div className="label-sm" style={{ color: 'var(--acc)' }}>Drafted to your squad</div>
              <div style={{ fontWeight: 700 }}>New striker · <span className="money">{fmtM(S.drafted.val)}</span></div>
            </div>
          </div>
        )}
      </div>

      <div className="sticky-foot">
        {drafted
          ? <button className="btn primary rise" onClick={next}>See the picks →</button>
          : <div className="label-sm" style={{ textAlign: 'center', padding: 6 }}>Tap a prospect to open its scout report</div>}
      </div>

      {open && <Dossier p={open} onClose={() => setOpen(null)} onDraft={() => confirmDraft(open)} />}
    </div>
  );
}

/* dossier overlay = chosen player-card design B (data sheet) */
function Dossier({ p, onClose, onDraft }) {
  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 40, display: 'flex', flexDirection: 'column' }}>
      <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'rgba(11,18,38,.42)', backdropFilter: 'blur(3px)', animation: 'scene-in .25s ease' }} />
      <div className="rise" style={{ position: 'absolute', left: 0, right: 0, bottom: 0, background: 'var(--app-1)', borderRadius: '26px 26px 0 0', padding: '14px 18px 26px', maxHeight: '92%', overflowY: 'auto', boxShadow: '0 -20px 60px rgba(11,18,38,.4)' }}>
        <div style={{ width: 42, height: 5, borderRadius: 5, background: 'var(--line-2)', margin: '0 auto 14px' }} />
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <span className="kicker">Scout report</span>
          <span className="pill">anonymous prospect</span>
        </div>
        <div style={{ display: 'flex', gap: 14 }}>
          <div style={{ width: 150, flexShrink: 0 }}><PlayerCardFull p={p} sm /></div>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <StatBars stats={p.stats} />
          </div>
        </div>
        <div className="divider" />
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <span className="label-sm">Market value</span>
          <span className="money" style={{ fontSize: 28 }}>{fmtM(p.val)}</span>
        </div>
        <div className="btn-row">
          <button className="btn ghost" style={{ flex: '0 0 38%' }} onClick={onClose}>Back</button>
          <button className="btn primary" onClick={onDraft}>Draft this prospect</button>
        </div>
      </div>
    </div>
  );
}

/* ---------------- WHOSE TURN (snake recap) ---------------- */
function TurnScreen({ S, next }) {
  const [now, setNow] = React.useState(0);
  const [done, setDone] = React.useState([0]);
  const [finished, setFinished] = React.useState(false);

  React.useEffect(() => {
    let i = 0;
    const seq = [1, 2, 3];
    const id = setInterval(() => {
      if (i >= seq.length) { clearInterval(id); setNow(null); setFinished(true); return; }
      const m = seq[i];
      setNow(m);
      setDone((d) => [...d, m]);
      i++;
    }, 850);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="scene">
      <Rail step={2} total={8} yr="24/25" phase="Pick order" />
      <div className="app-body">
        <SceneHead kicker="Round complete" title="The Picks"
          sub="Managers rotate in a snake order. Drafted prospects leave the board — order reverses next round so nobody hoards value." />

        <div className="surf" style={{ padding: '22px 18px', margin: '6px 0 18px' }}>
          <div className="label-sm" style={{ marginBottom: 14 }}>Striker draft · 24/25</div>
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
            <Snake now={now} done={done} />
          </div>
          <div style={{ textAlign: 'center', fontFamily: 'var(--font-d)', fontWeight: 700, fontSize: 22, color: finished ? 'var(--good)' : 'var(--acc)', textTransform: 'uppercase' }}>
            {finished ? 'All picks in' : MANAGERS[now] + ' is picking…'}
          </div>
        </div>

        <div className="surf rise" style={{ padding: 16, display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 118 }}><PlayerCardFull p={S.drafted} sm /></div>
          <div>
            <div className="label-sm">Your pick</div>
            <div style={{ fontWeight: 700, fontSize: 18, margin: '2px 0 6px' }}>New striker</div>
            <div className="money" style={{ fontSize: 22 }}>{fmtM(S.drafted.val)}</div>
          </div>
        </div>
      </div>
      <div className="sticky-foot"><button className="btn primary" disabled={!finished} onClick={next}>See my squad →</button></div>
    </div>
  );
}

/* ---------------- SQUAD (formation) ---------------- */
function SquadScreen({ S, next }) {
  // pre-filled squad + the freshly drafted ST
  const rows = [['GK'], ['CB', 'CB'], ['DM'], ['AM'], ['WF', 'ST']];
  const vals = { GK: 7.2, CB: 9.0, 'CB2': 6.2, DM: 13.5, AM: 21.0, WF: 2.6, ST: S.drafted ? S.drafted.val : 13 };
  const total = 7.2 + 9.0 + 6.2 + 13.5 + 21.0 + 2.6 + (S.drafted ? S.drafted.val : 13);
  let cbi = 0;
  return (
    <div className="scene">
      <Rail step={3} total={8} yr="24/25" phase="Your squad" />
      <div className="app-body">
        <SceneHead kicker="7 / 7 slots filled" title="The Squad"
          sub="Your roster, built one position per season. Outside the window, current values are visible — this total is what you're growing." />

        <div className="pitch" style={{ minHeight: 320, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          {rows.map((row, ri) => (
            <div className="prow" key={ri}>
              {row.map((pos, ci) => {
                const isNew = pos === 'ST';
                let v = vals[pos];
                if (pos === 'CB') { v = ci === 0 ? vals.CB : vals.CB2; }
                return (
                  <div className={"pslot filled"} key={ci}>
                    <div className="dot" style={isNew ? { boxShadow: '0 0 0 3px var(--acc-glow), 0 4px 14px var(--acc-glow), inset 0 1px 0 rgba(255,255,255,.5)' } : null}>{pos}</div>
                    <div className="val">{fmtM(v)}</div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>

        <div className="surf" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 18px', marginTop: 16, background: 'var(--ink)', color: '#fff' }}>
          <span className="label-sm" style={{ color: 'rgba(255,255,255,.6)' }}>Current squad value</span>
          <span className="money" style={{ fontSize: 26 }}>{fmtM(total)}</span>
        </div>
      </div>
      <div className="sticky-foot"><button className="btn primary" onClick={next}>Enter transfer window →</button></div>
    </div>
  );
}

/* ---------------- INTERSTITIAL ---------------- */
function Interstitial({ kicker, big, yr, p, cta, next }) {
  return (
    <div className="scene">
      <div className="inter">
        <div className="kicker">{kicker}</div>
        {yr && <div className="yr">{yr}</div>}
        <div className="big">{big}</div>
        {p && <p>{p}</p>}
      </div>
      <div className="sticky-foot"><button className="btn primary" onClick={next}>{cta} →</button></div>
    </div>
  );
}

Object.assign(window, { SetupScreen, DraftScreen, Dossier, TurnScreen, SquadScreen, Interstitial });
